<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Welcome extends CI_Controller {

	public function index()
	{
		$this->load->library('form_validation');
		$this->form_validation->set_rules('email',"Email","required");
    $this->form_validation->set_rules('password',"Password","required");
    $this->form_validation->set_rules('phone',"Contact","required");
		if ($this->form_validation->run() !== false) {
			$email = $this->input->post("email");
			$password = $this->input->post("password");
		  $contact = $this->input->post("phone");
			$data=array(
				"Email" => $email,
				"Password" => $password,
				"Contact" => $contact
			);
			$this->db->insert("user_details",$data);
			redirect(base_url('login'));
		}
		$this->load->view('sign');


	}


	public function login(){
		if (isset($_SESSION['curperson'])) {
			redirect(base_url('home'));
		} else{
		$this->load->library('form_validation');
		$this->load->model('LoginModel');
		$this->form_validation->set_rules("email", "Email", "required");
		$this->form_validation->set_rules("password", "Password", "required");

		if ($this->form_validation->run() !== false) {
			$email = $this->input->post("email");
			$password = $this->input->post("password");
			$flag = $this->LoginModel->checkCred($email, $password);
			if($flag){
				$_SESSION['curperson'] = $email;
				$this->session->unset_userdata('wrong');
				redirect(base_url('home'));
			}
			else{
				$this->session->set_flashdata("wrong", "Please check your credentials!");
			}
		}}
		$this->load->view('login');
	}

	public function home(){
		if (isset($_SESSION['curperson'])) {
			$this->load->view('home');
		} else{
			redirect(base_url('login'));
		}

	}

	public function logout(){
		$this->session->unset_userdata('curperson');
		redirect(base_url('login'));
	}




	public function main(){
		if (isset($_SESSION['curperson'])) {
			$this->load->view('all');
		} else{
			redirect(base_url('login'));
		}

	}



	public function hyd(){
		if (isset($_SESSION['curperson'])) {
			$this->load->view('hyderabad');
		} else{
			redirect(base_url('login'));
		}

	}


	public function mumbai(){
		if (isset($_SESSION['curperson'])) {
			$this->load->view('mumbai');
		} else{
				redirect(base_url('login'));
		}

}

	public function kolkata(){
		if (isset($_SESSION['curperson'])) {
			$this->load->view('kolkata');
		} else{
			redirect(base_url('login'));
		}

	}

	public function delhi(){
		if (isset($_SESSION['curperson'])) {
			$this->load->view('delhi');
		} else{
			redirect(base_url('login'));
		}

}

	public function birla(){
		if (isset($_SESSION['curperson'])) {
			$this->load->view('pagehyd.php/birla');
		} else{
			redirect(base_url('login'));
		}

	}


	public function charminar(){
		if (isset($_SESSION['curperson'])) {
			$this->load->view('pagehyd.php/charminar');
		} else{
			redirect(base_url('login'));
		}

	}


	public function hussain(){
		if (isset($_SESSION['curperson'])) {
			$this->load->view('pagehyd.php/hussain');
		} else{
			redirect(base_url('login'));
		}

	}

	public function golkonda(){
		if (isset($_SESSION['curperson'])) {
			$this->load->view('pagehyd.php/golkonda');
		} else{
			redirect(base_url('login'));
		}

	}

	//mumbai


	public function shivaji(){
		if (isset($_SESSION['curperson'])) {
			$this->load->view('pagemum.php/shivaji');
		} else{
			redirect(base_url('login'));
		}

	}


	public function gate_way_of_india(){
		if (isset($_SESSION['curperson'])) {
			$this->load->view('pagemum.php/gateway');
		} else{
			redirect(base_url('login'));
		}

	}


	public function marine_drive(){
		if (isset($_SESSION['curperson'])) {
			$this->load->view('pagemum.php/marine');
		} else{
			redirect(base_url('login'));
		}

	}

	public function mountmary_church(){
		if (isset($_SESSION['curperson'])) {
			$this->load->view('pagemum.php/mount');
		} else{
			redirect(base_url('login'));
		}

	}



	//delhi


	public function Akshardam_Temple(){
		if (isset($_SESSION['curperson'])) {
			$this->load->view('pagedel.php/akshardam');
		} else{
			redirect(base_url('login'));
		}

	}


	public function India_Gate(){
		if (isset($_SESSION['curperson'])) {
			$this->load->view('pagedel.php/indiagate');
		} else{
			redirect(base_url('login'));
		}

	}


	public function Lotus_Temple(){
		if (isset($_SESSION['curperson'])) {
			$this->load->view('pagedel.php/lotus');
		} else{
			redirect(base_url('login'));
		}

	}

	public function Qutub_Minar(){
		if (isset($_SESSION['curperson'])) {
			$this->load->view('pagedel.php/qutub');
		} else{
			redirect(base_url('login'));
		}

	}



	//kolkatta
	public function Belur_Math(){
		if (isset($_SESSION['curperson'])) {
			$this->load->view('pagkol.php/belur');
		} else{
			redirect(base_url('login'));
		}

	}


	public function Howrah_Bridge(){
		if (isset($_SESSION['curperson'])) {
			$this->load->view('pagkol.php/howrah');
		} else{
			redirect(base_url('login'));
		}

	}


	public function St_Pauls_Cathedral(){
		if (isset($_SESSION['curperson'])) {
			$this->load->view('pagkol.php/stpauls');
		} else{
			redirect(base_url('login'));
		}

	}

	public function Victoria_Memorial(){
		if (isset($_SESSION['curperson'])) {
			$this->load->view('pagkol.php/victoria');
		} else{
			redirect(base_url('login'));
		}
		;
	}
	//Payment
	public function payment(){
		if (isset($_SESSION['curperson'])) {
			$this->load->view('payment');
		} else{
			redirect(base_url('login'));
		}

	}


	public function aboutus(){
		if (isset($_SESSION['curperson'])) {
			$this->load->view('aboutus');
		} else{
			redirect(base_url('login'));
		}

	}


	//knowmore
	public function know_more(){
		if (isset($_SESSION['curperson'])) {
			$this->load->view('home');
		} else{
			redirect(base_url('login'));
		}
		$this->load->view('know_more');
	}

	//thank you
	public function thank_you(){
	
		$this->load->view('thank_you');
	}


}
