<?php $this->load->view('layout/header'); ?>
<body style="background:url('assets/images/jk.jpg'); background-size:cover; height:100px; width:100%">

        <div class="form " >
            <form class="login-form text-center" action="register"  method="post">
<br>
    <br>            <h2><i><b>Sign Up</b></i></h2>
                <div class="icons">
                    <a href="#"><i class="fab fa-facebook"></i></a>
                    <a href="#"><i class="fab fa-google"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>


                </div>

                <input  type="email" name="email" placeholder="Email" required>


                <input  type="password" name="password" placeholder="Password" required>
                <input  type="number" name="phone" placeholder="Contact" required>
                <button type="submit" name="button">Sign Up</button><hr>
                <p class="options"><a href="<?php echo base_url('login'); ?>">Have an Account </a></p>



            </form>
        </div>
      </div>
</body>

<?php $this->load->view('layout/footer'); ?>
