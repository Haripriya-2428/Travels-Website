<html>
    <head>

<title>
</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet"  type="text/css" href="style.css">
    <link rel="stylesheet" href="bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css?family=Josefin+Sans" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Tenali+Ramakrishna&display=swap" rel="stylesheet">

<link href="https://fonts.googleapis.com/css2?family=Architects+Daughter&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Piedra&family=Tenali+Ramakrishna&display=swap" rel="stylesheet">


     <style>
  /* Make the image fully responsive */
  .carousel-inner img {
    width: 100%;
    height: 100%;
  }
  </style>

</head>




<body class="how">

<!--navbar starting-->

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="#">EzTravels</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item active">
          <a class="nav-link " href="home">Home <span class="sr-only">(current)</span></a>
        </li>

        <li class="nav-item">
            <a class="nav-link" href="aboutus">About Us</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="main">Service</a>
          </li>

          <li class="nav-item">

            <a class="nav-link" href="logout">Logout</a>
          </li>
      </ul>
    </div>
  </nav>


<!--carousel-->


  <div id="demo" class="carousel slide" data-ride="carousel">
    <ul class="carousel-indicators">
      <li data-target="#demo" data-slide-to="0" class="active"></li>
      <li data-target="#demo" data-slide-to="1"></li>
      <li data-target="#demo" data-slide-to="2"></li>
    </ul>
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img src="<?php echo base_url('assets/images/car.jpg'); ?>" alt="Los Angeles" width="1100" height="500">
        <div class="carousel-caption">
          <h3><b>EzTravels</b></h3>
          <p>We had such a great time in LA!</p>
        </div>
      </div>
      <div class="carousel-item">
        <img src="<?php echo base_url('assets/images/car1.jpg'); ?>" alt="Chicago" width="1100" height="500">
        <div class="carousel-caption">
          <h3><b>EzTravels</b></h3>
          <p>The Beauty Of Kerala</p>
        </div>
      </div>
      <div class="carousel-item">
        <img src="<?php echo base_url('assets/images/car2.jpg'); ?>" alt="New York" width="1100" height="500">
        <div class="carousel-caption">
          <h3><b>EzTravels</b></h3>
          <p>We love the Big Apple!</p>
        </div>
      </div>
    </div>



    <a class="carousel-control-prev" href="#demo" data-slide="prev">
      <span class="carousel-control-prev-icon"></span>
    </a>
    <a class="carousel-control-next" href="#demo" data-slide="next">
      <span class="carousel-control-next-icon"></span>
    </a>
  </div>



<!--about us-->

<!--service part-->

<section>
<div class="hie">


<div class="container-field">
<div class="text-center bg-dark text-light p-2"><h1>Services We Provide</h1></div>
<div class="card bg-light mt-3 mb-3"></div>
<div class="row">

    <div class="col-lg-4 col-md-4 col-12 pb-4">
    <div class="card text-center" style="width:400px">
    <img class="card-img-top" style="width:400px height:400px" src="<?php echo base_url('assets/images/1.Hyderabad/Hyderabad.jpg'); ?>" alt="Card image">
    <div class="card-body">
      <h4 class="card-title">Hyderabad</h4>
      <h6 class="card-text">Click the Profile to know about the services in Hyderabad</h6>
      <a href="hyd" class="btn btn-primary">See Profile</a>
    </div>
    </div>
  </div>

      <div class="col-lg-4 col-md-4 col-12">
  <div class="card text-center" style="width:400px">
    <img class="card-img-top a" src="<?php echo base_url('assets/images/kolkata.jpg'); ?>" alt="Card image">
    <div class="card-body">
      <h4 class="card-title">Kolkata</h4>
      <h6 class="card-text">Click the Profile to know about the services in Kolkata</h6>
      <a href="kolkata" class="btn btn-primary">See Profile</a>
    </div>
    </div>
  </div>
  <div class="col-lg-4 col-md-4 col-12">
  <div class="card text-center" style="width:400px">
    <img class="card-img-top a" src="<?php echo base_url('assets/images/mumbai.jpg'); ?>" alt="Card image">
    <div class="card-body">
      <h4 class="card-title">Mumbai</h4>
      <h6 class="card-text">Click the Profile to know about the services in Mumbai</h6>
      <a href="mumbai" class="btn btn-primary"> See Profile </a>
    </div>
    </div>
  </div>

  </div>
</div>
</section>


<!--contact us-->


<section class="bg-warning">

<article class="py-5 text-center">
<div class="row">
    <div class="col-md-6">
      <h2>Contact us at: </h2>
      <h3>+91-9912068301</h3>
    </div>
    <div class="col-md-6">
      <h2>Email us at:</h2>
      <h3>eztravels@gmail.com</h3>
    </div>
</div>



</article>






</section>


<footer>
<h4 class="text-center text-danger bg-dark p-5">@Copyright Designed and developed by Team EzTravels</h4>


</footer>







<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>


    </body>
</html>
