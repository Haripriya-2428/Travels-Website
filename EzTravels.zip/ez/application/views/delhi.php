<html>
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" type="text/css" href="style.css">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</head>
</html>
<body>



    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="#">EzTravels</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
              <a class="nav-link " href="home">Home <span class="sr-only">(current)</span></a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="aboutus">About Us</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="main">Service</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="logout">Logout</a>
              </li>
          </ul>
        </div>
      </nav>



    <style>
    .height250{
        height:250px;
        width:80%;
        padding:5;
        margin:15;
        border-radius:35px;
        background:url(assets/images/h2.jpg);

    }

    p{
        text-align: center;
        color: darkred;
        text-decoration:underline;

    }
    </style>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-6 std-img">
           <img class='height250' src="<?php echo base_url('assets/images/3.Delhi/Sub places of delhi/akshardam temple.jpg') ?>" class="img-fluid std-img "><p><button><a href="Akshardam_Temple">Akshardam Temple</a></button></p><br>
        </div>
        <div class="col-md-6 std-img ">
            <img class='height250' src="<?php echo base_url('assets/images/3.Delhi/Sub places of delhi/India gate.jpg')?>" class="img-fluid std-img"><p><button><a href="India_Gate">India Gate</a></button></p><br>
        </div>
        <div class="col-md-6 std-img" class="img-fluid std-img">
            <img class='height250' src="<?php echo base_url('assets/images/4.kolkatta/sub places of kolkatta/st pauls cathedral.jpg')?>"><p><button><a href="Lotus_Temple">Lotus Temple</a></button></p>
        </div>
        <div class="col-md-6 std-img">
            <img class='height250' src="<?php echo base_url('assets/images/4.kolkatta/sub places of kolkatta/VICTORIA-MEMORIAL.jpg')?>" class="img-fluid std-img'?> "><p><button><a href="Qutub_Minar"> Qutub Minar</a> </button></p><br>
        </div>

        </div>
    </div>
</div>
</body>
</html>
