<html>

<style>
h1{

  color:black;

}


body{

  background:url("assets/images/pink.jpeg");
}


p{
  color:black;
}

.hello{
  border-radius:35px;
}

</style>


<body>


<h1>

Mountmary Church </h1>
<div class="hello">

<img src= "<?php echo base_url('assets/images/inside/440px-Mount_Mary_Church_(Bombay).jpg') ?>">
</div>

<p><i><b>The Basilica of Our Lady of the Mount, more commonly known as Mount Mary Church, is a Roman Catholic Basilica located in Bandra, Mumbai. The feast of the Blessed Virgin Mary is celebrated here on the first Sunday after 8 September, the birthday of the Virgin Mary. The feast is followed by a week-long celebration known locally as the Bandra Fair and is visited by thousands of people. Many pilgrims visit the Basilica of Our Lady of the Mount in order to pray for their mannat (wish) to come true.
</b></i></p>

<br>
<br>

<button ><a href="payment"> Payment </button>


</body>

</html>
