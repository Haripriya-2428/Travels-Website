<html>

<style>
h1{

  color:black;

}


body{

  background:url("assets/images/pink.jpeg");
}


p{
  color:black;
}

.hello{
  border-radius:35px;
}

</style>


<body>


<h1> Chatrapati shivaji terminus</h1>
<div class="hello">

<img src= "<?php echo base_url('assets/images/inside/480px-CHATRAPATI_SHIVAJI_MAHARAJ_TERMINUS.jpg') ?>">
</div>

<p><i><b>
chatrapati shivaji terminus

Chhatrapati Shivaji Maharaj Terminus (station code: CSTM (mainline)/ST (suburban)), also known by its former name Victoria Terminus (station code: BBVT/VT), is a historic terminal train station and UNESCO World Heritage Site in Mumbai, Maharashtra, India.

The terminus was designed by British born architectural engineer Frederick William Stevens, in an exuberant Italian Gothic style. Its construction began in 1878, in a location south of the old Bori Bunder railway station, and was completed in 1887, the year marking 50 years of Queen Victoria's rule, the building being named, Victoria Terminus.

</b></i></p>

<br>
<br>
<button ><a href="payment"> Payment </button>


</body>

</html>
