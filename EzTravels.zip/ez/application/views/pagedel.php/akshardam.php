<html>

<style>
h1{

  color:black;

}


body{

  background:url("assets/images/pink.jpeg");
}


p{
  color:black;
}

.hello{
  border-radius:35px;
}

</style>


<body>


<h1> Akshardham</h1>
<div class="hello">

<img src= "<?php echo base_url('assets/images/inside/440px-Swaminarayan_Akshardham_New_Delhi_Angle.jpg') ?>">
</div>

<p><i><b>Swaminarayan Akshardham (New Delhi) is a Hindu temple, and a spiritual-cultural campus in New Delhi, India. Also referred to as Akshardham Temple or Delhi Akshardham, the complex displays millennia of traditional Hindu and Indian culture, spirituality, and architecture. Inspired by Yogiji Maharaj and created by Pramukh Swami Maharaj, it was constructed by BAPS.

The temple was officially opened on 6 November 2005 by Pramukh Swami Maharaj in the presence of Dr. A. P. J. Abdul Kalam, Manmohan Singh, L.K Advani and B.L Joshi. The temple, at the centre of the complex, was built according to the Vastu shastra and Pancharatra shastra.

In Swaminarayan Akshardham New Delhi, similar to its predecessor Swaminarayan Akshardham in Gandhinagar, Gujarat, the main shrine is the focal point and maintains the central position of the entire complex. There are various exhibition halls which provide information about the life and work of Swaminarayan. The designers of the complex have adopted contemporary modes of communication and technology to create the various exhibition halls.
</b></i></p>

<br>
<br>

<button ><a href="payment"> Payment </button>


</body>

</html>
