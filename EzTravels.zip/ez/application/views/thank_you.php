<html>


<body>
<br>
<br>

<br>
<br>

<img src=<?php echo base_url('assets/images/thanku.jpg') ?>>


</body>
</html>
