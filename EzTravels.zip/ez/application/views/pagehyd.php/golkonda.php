<html>

<style>
h1{

  color:black;

}


body{

  background:url("assets/images/pink.jpeg");
}


p{
  color:black;
}

.hello{
  border-radius:35px;
}

</style>


<body>


<h1> Golkonda </h1>
<div class="hello">

<img src= "<?php echo base_url('assets/images/inside/480px-Golkonda_Fort_001.jpg') ?>">
</div>

<p><i><b>Golconda Fort, also known as Golkonda (Telugu. "shepherds' hill") is a fortified citadel and an early capital city of the Qutb Shahi dynasty (c.1512–1687), located in Hyderabad, Telangana, India. Because of the vicinity of diamond mines, especially Kollur Mine, Golconda flourished as a trade centre of large diamonds, known as the Golconda Diamonds. The region has produced some of the world's most famous diamonds, including the colourless Koh-i-Noor (now owned by the United Kingdom), the blue Hope (United States), the pink Daria-i-Noor (Iran), the white Regent (France), the Dresden Green (Germany), and the colourless Orlov (Russia), Nizam and Jacob (India), as well as the now lost diamonds Florentine Yellow, Akbar Shah and Great Mogul.

</b></i></p>

<br>
<br>

<button ><a href="payment"> Payment </button>



</body>

</html>
