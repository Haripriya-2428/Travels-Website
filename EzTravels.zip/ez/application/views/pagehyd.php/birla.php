<html>

<style>
h1{

  color:black;

}


body{

  background :url("assets/images/pink.jpeg");
  background-size: cover;
  width:100%;
  height:150px;
}


p{
  color:black;
}

.hello{
  border-radius:35px;
}

</style>


<body>


<h1> Birla mandir </h1>
<div class="hello">

<img src= "<?php echo base_url('assets\images\1.Hyderabad\sub places in HYD\birla-mandir.jpg') ?>">
</div>

<p><i><b>Birla Mandir is a Hindu temple,
 built on a 280 feet (85 m) high hillock called Naubath Pahad on a 13 acres (53,000 m2) plot. <br>
 The construction took 10 years and was opened in 1976 by Swami Ranganathananda of Ramakrishna Mission. <br>
 The temple was constructed by Birla Foundation, which has also constructed several similar temples across <br>
 India, all of which are known as Birla Mandir.</b></i></p>

<br>

<button ><a href="payment"> Payment </button>


</body>

</html>
