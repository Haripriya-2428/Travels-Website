<section>
  <br><br><br>
  <div class="container bg-white pt-5 pb-5 p-5">
    <form action="" method="post">
        <div class="row">
          <div class="col-md-5 center">
            <div class="form-group">
              <input type="text"  id="search" class="form-control rounded-0"  autocomplete="off" >
              <button type="button" class="btn btn-primary search-button rounded-0" name="button">Search</button>
            </div>
          </div>
        </div>
    </form>
  </div>
</section>
