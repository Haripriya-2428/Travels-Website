<html >
<head>
<link href="stylesheet.css" rel="stylesheet">
<meta charseet="UTF-8">
<title> Payment</title>
</head>
<body>
  <style>

  *{
      margin:0;
      padding:0;
      box-sizing:border-box;
      outline: none;
      text-decoration: none;
      font-family: Arial, Helvetica, sans-serif;
  }

  body{
      background: url(assets/images/mn.jpg) no-repeat center center ;
      background-size:cover ;
      width:100%;
      height:100vh;
  }

  .wrapper{
      position:absolute;
      top:0%;
      left:50%;
      transform: translate(-50%,50%);
      width:500px;
      height: 350px;

  }
  .wrapper .checkout_wrapper{
      width:100%;
      height:100%;
      display: flex;
  }

  .wrapper .checkout_wrapper .product_info{
      width:45%;
      background: #e85c4d;
      border-top-left-radius:20px;
      border-bottom-left-radius: 20px;
      position: relative;
  }

  .wrapper .checkout_wrapper .product_info img{

      width:240px;
      margin-left:5px;
      margin-top: 30px; //ezphoto
  }

  .wrapper .checkout_wrapper .product_info .content{
      text-align: center;
      margin-top: 5px;
      color:#fff;
      text-transform: uppercase;
  }

  .wrapper .checkout_wrapper .product_info .content h3{
      font-size: 18px;
      line-height: 18px;
      letter-spacing: 3px;

  }

  .wrapper .checkout_wrapper .product_info .content p{
      font-size: 14px;
      margin-top: 10px;
  }


  .wrapper .checkout_wrapper .checkout_form{
      width:55%;

      background:url(assets/images/payment.jpeg)  //payment section
      border-top-right-radius: 20px;
      border-bottom-right-radius: 20px;
      padding: 50px 30px;
  }
  .wrapper .checkout_wrapper .checkout_form p{
      margin-bottom: 5px;
      font-size: 20px;
      text-transform: uppercase;
  }

  .wrapper .checkout_wrapper .checkout_form .section{

      margin-bottom: 15px;
  }

  .wrapper .checkout_wrapper .checkout_form .section input[type="text"]{
      width:100%;
      padding:10px;
      border:5px solid yellow;

  }

  .wrapper .checkout_wrapper .checkout_form .section input[type="text"]:focus{
      border-color: blue;
  }

  .wrapper .checkout_wrapper .checkout_form .section.last_section{
      display:flex;
      justify-content: space-between;
  }

  .wrapper .checkout_wrapper .checkout_form.section .item{
      width:48%;
  }
  .wrapper .checkout_wrapper .checkout_form .btn{
      background: black;
      padding:5%;
      border-radius: 15px;
      text-align: center;
      margin-top: 25px;
  }

  .wrapper .checkout_wrapper .checkout_form .btn a{
      color: red;
      letter-spacing: 2px;

  }

</style>
<body>
    <div class="wrapper">
        <div class="checkout_wrapper">
            <div class="product_info">
                <img src="assets/images/Ez_Travels_LOGO.jpg" alt="">
                <div class="content">
                    <h3>EzTravels <br> Best service</h3>
                    <P>500</P>
                </div>
            </div>

           <div class="checkout_form">
               <p>Payment Section</p>
                <div class="details">
                    <div class="section">
                        <input type="text" placeholder="Card Number">
                    </div>
                    <div class="section">
                        <input type="text" placeholder="Card Holder Number">
                    </div>
                    <div class="section last_section">
                        <input type="text" placeholder="Expire Date">
                    </div>
                    <div class="item">
                        <input type="text" placeholder="CVV">


                    </div>

                </div>
                    <div class="btn">
                        <a href="thank_you">Pay</a>
                    </div>

           </div>

        </div>
    </div>

</body>

</html>
