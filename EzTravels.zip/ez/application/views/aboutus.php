<html>
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="ok.css">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>

</head>
<body>

  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="#">EzTravels</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item active">
          <a class="nav-link " href="home">Home <span class="sr-only">(current)</span></a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="aboutus">About Us</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="main">Service</a>
        </li>
        
        <li class="nav-item">

          <a class="nav-link" href="logout">Logout</a>
        </li>
      </ul>
    </div>
  </nav>
  <style>
  body{
    background-image: linear-gradient(to right, red, blue);

  }
  </style>

  <body>

    <section>

      <div class="container-field mb-5 ml-5">

        <h1 class="text-center text-white text-capitalize pt-5"> about us  </h1>
        <hr class="w-25 mx-auto ">
        <div class="row">
          <div class="col-lg-6 col-md-6 col-12" >
            <img src="<?php echo base_url('assets/images/aboutpage.jpeg'); ?>" class="img-fluid h-75" alt="travel" >
          </div>
          <div class="col-lg-6 col-md-6 col-12  ">
            <!-- <h1 class="text-white">Who are we?</h1> -->

            <div class="card">
              <p >
                <b>EzTravels</b> is the world's leading bus ticket booking company.
                It operates in 6 countries (India, Malaysia, Singapore, Indonesia, Peru, and Colombia).
                <b>EzTravels</b> has sold over 180 million bus tickets worldwide through the <b>EzTravels</b> website and app.
                With over 17 million satisfied customers, EzTravels has set the bar quite high.</p>

                <p >Only for you we got rid of the long queues on jammed streets and bus stations for bus tickets, we got rid of agents cheating you with jacked up bus ticket prices, we are the pioneers who revolutionized the online bus booking in India. Booking a bus ticket from your couch or when you are on the move was made possible by us by just logging on to Eztravels.com.

                  You could book bus tickets to anywhere in India from over 2500 bus operators covering over 100000 routes for Sleeper, AC, Semi luxury, Luxury, and coaches from Volvo, Scania, Ashok Leyland to Mercedes at click of a button and to make payment convenient we have multiple payment options like, Debit/Credit, Net Banking.

                  EzTravels Customer Service representatives are available 24 X7 365 days a year, who are happy to help you book your bus ticket online or attend to any of your queries.

                  So next time you think of bus, just Ez Travels it...</p>
                </div>

                <!-- <button class="bg-dark text-blue"><a href="know_more"><b>know More</b></a></button> -->
              </div>
            </div>
          </div>
        </div>

      </section>
    </body>
    </html>
