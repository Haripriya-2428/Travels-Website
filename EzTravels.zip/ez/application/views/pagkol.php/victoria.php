<html>

<style>
h1{

  color:black;

}


body{

  background:url("assets/images/pink.jpeg");
}


p{
  color:black;
}

.hello{
  border-radius:35px;
}

</style>


<body>


<h1> Victoria Memorial </h1>
<div class="hello">

<img src= "<?php echo base_url('assets/images/inside/520px-Victoria_Memorial_situated_in_Kolkata.jpg') ?>">
</div>

<p><i><b>The Victoria Memorial is a large marble building in Kolkata, West Bengal, India, which was built between 1906 and 1921. It is dedicated to the memory of Queen Victoria, then Empress of India, and is now a museum and tourist destination under the auspices of the Ministry of Culture.The memorial lies on the Maidan (grounds) by the bank of the Hooghly River, near Jawaharlal Nehru Road (better known as Chowringhee Road).

</b></i></p>

<br>
<br>

<button ><a href="payment"> Payment </button>


</body>

</html>
