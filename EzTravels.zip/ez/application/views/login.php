<?php $this->load->view('layout/header'); ?>

<body style="background:url('assets/images/jk.jpg'); background-size:cover; height:100px; width:100%">
<body class="hello">
        <div class="form">
            <form class="login-form" action="" method="post" >
                <h2><i><b>Login</b></i></h2>
                <div class="icons">
                  <a href="#"><i class="fab fa-google"></i></a>
                    <a href="#"><i class="fab fa-facebook"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>


                </div>

                <input  type="text" name="email" value="" placeholder="Email" required>
                <input  type="password" name="password" value="" placeholder="Password" required>
                <button type="submit" name="button">Login</button><br>
                <p class="options">Not Registered?<br><hr><tab><a href="<?php echo base_url('register'); ?>">Create an Account </a></p></tab>



            </form>
        </div>
</body>
<?php $this->load->view('layout/footer'); ?>
